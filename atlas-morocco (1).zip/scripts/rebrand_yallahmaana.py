from pathlib import Path

root = Path('/home/ubuntu/atlas-morocco')
logo = '/manus-storage/yallahmaana-logo_e62711b1.png'

site = root / 'client/src/components/site.tsx'
s = site.read_text()
s = s.replace("document.title = `${title} · Atlas & Beyond`", "document.title = `${title} · Yallahmaana`")
s = s.replace("name:'Atlas & Beyond'", "name:'Yallahmaana'")
s = s.replace('Atlas & Beyond', 'Yallahmaana')
s = s.replace('atlas & beyond', 'yallahmaana')
s = s.replace('ATLAS & BEYOND', 'YALLAHMAANA')
s = s.replace('<Link href="/" className="brand" aria-label="Yallahmaana, accueil"><span className="brand-mark">A<span>+</span></span><span className="brand-word">yallahmaana</span></Link>', f'<Link href="/" className="brand" aria-label="Yallahmaana, accueil"><img className="brand-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
# If the preceding replacement did not match because the brand was still in its original form.
s = s.replace('<Link href="/" className="brand" aria-label="Atlas & Beyond, accueil"><span className="brand-mark">A<span>+</span></span><span className="brand-word">atlas <i>& beyond</i></span></Link>', f'<Link href="/" className="brand" aria-label="Yallahmaana, accueil"><img className="brand-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
s = s.replace('<Link href="/" className="brand brand-light"><span className="brand-mark">A<span>+</span></span><span className="brand-word">yallahmaana</span></Link>', f'<Link href="/" className="brand brand-light"><img className="brand-logo footer-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
s = s.replace('<Link href="/contact" className="button button-primary">Parlons de votre projet <ArrowRight size={16}/></Link>', '<Link href="/mon-compte" className="drawer-account-link">Mon compte <UserRound size={17}/></Link><Link href="/contact" className="button button-primary">Parlons de votre projet <ArrowRight size={16}/></Link>')
site.write_text(s)

account = root / 'client/src/pages/AccountPages.tsx'
s = account.read_text()
s = s.replace('Atlas & Beyond', 'Yallahmaana').replace('atlas & beyond', 'yallahmaana').replace('ATLAS & BEYOND', 'YALLAHMAANA')
s = s.replace('<Link href="/" className="auth-brand"><span className="brand-mark">A<span>+</span></span><span className="brand-word">yallahmaana <i>& beyond</i></span></Link>', f'<Link href="/" className="auth-brand"><img className="brand-logo auth-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
s = s.replace('<Link href="/" className="auth-brand"><span className="brand-mark">A<span>+</span></span><span className="brand-word">atlas <i>& beyond</i></span></Link>', f'<Link href="/" className="auth-brand"><img className="brand-logo auth-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
account.write_text(s)

pages = root / 'client/src/pages/Pages.tsx'
s = pages.read_text().replace('Atlas & Beyond', 'Yallahmaana').replace('atlas & beyond', 'yallahmaana').replace('ATLAS & BEYOND', 'YALLAHMAANA')
pages.write_text(s)

html = root / 'client/index.html'
s = html.read_text().replace('#123B32', '#2498D0').replace('Atlas & Beyond — Voyages d’aventure au Maroc', 'Yallahmaana — Voyages et aventures').replace("fill='%23123B32'", "fill='%232498D0'").replace("fill='%23F4EBDD'", "fill='%23FFB51B'")
html.write_text(s)

css = root / 'client/src/index.css'
s = css.read_text()
s = s.replace('--forest:#123B32; --forest-dark:#09251F; --forest-soft:#1d5144; --sand:#F4EBDD; --cream:#FFFDF8; --terracotta:#C96B45; --orange:#E58B4A; --charcoal:#18201E; --muted:#66736D; --border:#DDE4DC;', '--forest:#2498D0; --forest-dark:#075A91; --forest-soft:#167CB8; --sand:#FFF3D5; --cream:#FFFFFF; --terracotta:#FFB51B; --orange:#F39A16; --charcoal:#153247; --muted:#5D7180; --border:#D8E6EF;')
s += '''\n/* Yallahmaana brand */\n.brand-logo{display:block;width:168px;height:auto;max-height:62px;object-fit:contain;object-position:left center}.site-header:not(.site-header-scrolled) .brand-logo{background:rgba(255,255,255,.95);border-radius:10px;padding:5px 9px}.footer-logo{width:175px;background:var(--white);border-radius:9px;padding:5px 8px}.auth-logo{width:210px;background:rgba(255,255,255,.96);border-radius:10px;padding:7px 11px}.drawer-account-link{display:flex;align-items:center;justify-content:space-between;padding:14px 4px;margin-bottom:12px;color:var(--forest);font-weight:700;border-bottom:1px solid var(--border)}\n@media (max-width:820px){.brand-logo{width:145px;max-height:48px}.site-header:not(.site-header-scrolled) .brand-logo{padding:4px 7px}.mobile-drawer{width:min(92vw,390px);padding:20px}.mobile-drawer .drawer-links a{font-size:18px;padding:13px 4px}.account-shell .account-mobile-menu{display:grid;flex:none}.account-shell .account-top-actions{min-width:0}.account-shell .account-topbar{gap:12px}.account-shell .account-topbar>div:first-child{min-width:0}.account-shell .account-topbar h1{overflow-wrap:anywhere}.account-sidebar{z-index:220}.account-drawer-backdrop{z-index:210}.auth-logo{width:175px}}\n@media (max-width:520px){.brand-logo{width:136px}.auth-logo{width:155px}.account-sidebar{width:min(88vw,310px)}.account-sidebar-head{padding:18px 16px}.account-sidebar nav a{min-height:45px}.account-logout{margin:10px 16px 16px}.account-main{min-width:0}.account-top-actions{flex-shrink:0}.account-notification{width:34px;height:34px}.account-mobile-menu{width:35px;height:35px}.auth-brand{top:20px;left:20px}}\n'''
css.write_text(s)

manifest = root / 'client/public/manifest.json'
if manifest.exists():
 s = manifest.read_text().replace('Atlas & Beyond', 'Yallahmaana').replace('atlasandbeyond', 'yallahmaana')
 manifest.write_text(s)
