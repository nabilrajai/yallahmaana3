from pathlib import Path
p=Path('/home/ubuntu/atlas-morocco/client/src/pages/Pages.tsx')
s=p.read_text().replace('\u200b','')
p.write_text(s)
