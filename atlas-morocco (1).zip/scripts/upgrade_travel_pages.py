from pathlib import Path

root = Path('/home/ubuntu/atlas-morocco')

site = root / 'client/src/components/site.tsx'
s = site.read_text()
s = s.replace('    <div className="announcement"><div className="container announcement-inner"><span><Sparkles size={13}/> Nouveaux départs d’automne · petits groupes, grands souvenirs</span><Link href="/voyages">Voir les prochaines dates <ArrowRight size={13}/></Link></div></div>\n', '')
site.write_text(s)

# Replace brand contact details everywhere in user-facing source, metadata and sitemap.
for path in [root / 'client/src', root / 'client/public', root / 'client/index.html', root / 'PROJECT_NOTES.md']:
    paths = path.rglob('*') if path.is_dir() else [path]
    for file in paths:
        if not file.is_file() or file.suffix not in {'.tsx', '.ts', '.css', '.html', '.json', '.xml', '.md'}:
            continue
        text = file.read_text()
        text = text.replace('bonjour@atlasandbeyond.ma', 'bonjour@yallahmaana.com')
        text = text.replace('atlasandbeyond.ma', 'yallahmaana.com')
        text = text.replace('https://atlasandbeyond.com', 'https://yallahmaana.com')
        file.write_text(text)

# Add the admin-friendly HTML field to the trip model.
types = root / 'client/src/types/index.ts'
s = types.read_text().replace('accommodation: string; meetingPoint: string', 'accommodation: string; meetingPoint: string; programHtml?: string')
types.write_text(s)

content = root / 'client/src/data/content.ts'
s = content.read_text()
galleries = {
    'img.nord,img.heroSecondary,img.heroMain': 'img.nord,img.heroSecondary,img.heroMain,img.mountain,img.heroPeople,img.imssouane,img.kayak,img.paddle,img.articleBeach,img.team,img.desert,img.balloon',
    'img.desert,img.mountain,img.heroPeople': 'img.desert,img.mountain,img.heroPeople,img.heroSecondary,img.nord,img.paddle,img.balloon,img.articleSnow,img.team,img.kayak,img.imssouane,img.heroMain',
    'img.imssouane,img.paddle,img.heroSecondary': 'img.imssouane,img.paddle,img.heroSecondary,img.heroMain,img.nord,img.kayak,img.articleBeach,img.heroPeople,img.mountain,img.balloon,img.desert,img.team',
    'img.mountain,img.team,img.heroPeople': 'img.mountain,img.team,img.heroPeople,img.nord,img.heroSecondary,img.desert,img.articleSnow,img.balloon,img.paddle,img.kayak,img.imssouane,img.heroMain',
}
for old, new in galleries.items():
    s = s.replace(f'gallery:[{old}]', f'gallery:[{new}]')
# Generate safe editorial HTML from the itinerary until a CMS/API supplies programHtml.
marker = ']\n\nexport const destinations'
insert = "]\n\ntrips.forEach(trip => {\n  if (!trip.programHtml) trip.programHtml = trip.itinerary.map(day => `<article><span>${day.day}</span><h3>${day.title}</h3><p>${day.description}</p>${day.tag ? `<small>${day.tag}</small>` : ''}</article>`).join('')\n})\n\nexport const destinations"
s = s.replace(marker, insert)
content.write_text(s)

pages = root / 'client/src/pages/Pages.tsx'
s = pages.read_text()
old = '<div className="detail-copy"><span className="eyebrow">Le fil de l’aventure</span><h2>Un itinéraire qui se vit autant qu’il se raconte.</h2><div className="itinerary">{trip.itinerary.map(day=><div className="itinerary-day" key={day.day}><span className="itinerary-number">{day.day}</span><div><span className="eyebrow">{day.tag}</span><h3>{day.title}</h3><p>{day.description}</p></div></div>)}</div></div>'
new = '<div className="detail-copy"><span className="eyebrow">Le fil de l’aventure</span><h2>Un itinéraire qui se vit autant qu’il se raconte.</h2><div className="trip-program-html" dangerouslySetInnerHTML={{__html:trip.programHtml || trip.itinerary.map(day=>`<article><span>${day.day}</span><h3>${day.title}</h3><p>${day.description}</p><small>${day.tag || ''}</small></article>`).join(\'\')}}/></div><div className="trip-gallery-section"><div className="section-topline"><div><span className="eyebrow">Carnet de route</span><h2>Plus de moments à vivre.</h2></div><span className="gallery-count">{trip.gallery.length} images</span></div><div className="trip-gallery-grid">{trip.gallery.map((image,i)=><figure key={`${image}-${i}`}><Image src={image} alt={`${trip.title} — image ${i+1}`} /><figcaption>{String(i+1).padStart(2,\'0\')}</figcaption></figure>)}</div></div>'
if old not in s:
    raise SystemExit('Trip detail itinerary block not found')
s = s.replace(old, new)
pages.write_text(s)
