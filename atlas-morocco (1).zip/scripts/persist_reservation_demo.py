from pathlib import Path
p=Path('/home/ubuntu/atlas-morocco/client/src/pages/Pages.tsx')
s=p.read_text()
old="  const confirmPeople=(e:FormEvent)=>{e.preventDefault();setError('');if(!people){setError('Indiquez le nombre de personnes.');return}if(user){setStep(3)}else setStep(2)}"
new="  const saveReservation=()=>{try{const key='yallahmaana_reservations';const current=JSON.parse(localStorage.getItem(key)||'[]');current.unshift({id:`res_${Date.now()}`,tripSlug:trip.slug,tripTitle:trip.title,people:Number(people),departure:trip.departure,status:'demande reçue'});localStorage.setItem(key,JSON.stringify(current))}catch{}}\n  const confirmPeople=(e:FormEvent)=>{e.preventDefault();setError('');if(!people){setError('Indiquez le nombre de personnes.');return}if(user){saveReservation();setStep(3)}else setStep(2)}"
if old not in s: raise SystemExit('confirmPeople block not found')
s=s.replace(old,new,1)
s=s.replace("try{await register(form);setStep(3);toast.success", "try{await register(form);saveReservation();setStep(3);toast.success",1)
p.write_text(s)
