# Atlas & Beyond — implementation notes

## Product direction

Atlas & Beyond is a French-language Moroccan adventure travel frontend with an editorial travel-magazine aesthetic: forest green, warm sand, terracotta accents, Fraunces display type, DM Sans body type, full-bleed photography, generous whitespace, and compact motion. The reference journey was used as an information-architecture input only; the interface and copy were rebuilt as a distinct design system.

## Route list

| Route | Purpose |
|---|---|
| `/` | Homepage / discovery hub |
| `/voyages` | Group-trip listing with search panel |
| `/voyages/:slug` | Reusable trip-detail template |
| `/destinations` | Destination explorer |
| `/destinations/:slug` | Reusable destination-detail template |
| `/activites` | Express-activity listing |
| `/activites/:slug` | Reusable activity-detail template |
| `/voyages-prives` | Private and custom travel |
| `/entreprises` | Business, team-building, and seminars |
| `/a-propos` | Story, values, and travel philosophy |
| `/avis` | Review listing |
| `/blog` | Article listing |
| `/blog/:slug` | Article detail with structured data |
| `/contact` | Contact and frontend inquiry form |
| `/faq` | FAQ accordion |
| `/mentions-legales` | Legal information |
| `/politique-de-confidentialite` | Privacy page |
| `/conditions-generales` | Terms / conditions page |
| fallback | Accessible 404 page |

## Shared components

The reusable UI lives in `client/src/components/site.tsx` and includes `Layout`, sticky responsive `Header`, mobile drawer, `Footer`, `SEO`, `Breadcrumbs`, `SearchPanel`, `TripCard`, `ActivityCard`, `FAQAccordion`, `InquiryForm`, `TestimonialCarousel`, `FilterBar`, `TrustStrip`, and shared button/image primitives. Page composition lives in `client/src/pages/Pages.tsx`, while routing is kept in `client/src/App.tsx`.

## Data model

Typed interfaces are defined in `client/src/types/index.ts`: `Trip`, `Activity`, `Destination`, `Article`, `Testimonial`, `Partner`, `FAQ`, `ItineraryDay`, `Price`, and `Availability`. Local structured content is in `client/src/data/content.ts`. Image URLs are centralized in `client/src/data/imageManifest.ts` so licensed assets can be swapped without touching page components.

## Image URLs used

The first version uses publicly accessible image URLs from the reference site wherever available, including:

- `https://triplan.ma/wp-content/plugins/Triplan-CRM/assets/img/website/home-v5/ph-group-bridge.jpg?ver=1785345719`
- `https://triplan.ma/wp-content/plugins/Triplan-CRM/assets/img/website/home-v5/ph-cove-boats.jpg?ver=1785345717`
- `https://triplan.ma/wp-content/plugins/Triplan-CRM/assets/img/website/home-v5/ph-friends-van.jpg?ver=1785345718`
- `https://triplan.ma/wp-content/uploads/2025/03/CARABLANCA-1024x1024.png`
- `https://triplan.ma/wp-content/uploads/2025/08/best-beaches-in-morocco-jpg_header-71380-2-1024x683.jpeg`
- `https://triplan.ma/wp-content/uploads/2025/04/Tazekka-Bouhadli-1-e1746746015102-1024x642.png`
- `https://triplan.ma/wp-content/uploads/2026/02/ChatGPT-Image-22-fevr.-2026-23_58_08.png`
- `https://triplan.ma/wp-content/uploads/2026/02/Balade-en-bateau-1024x1024.png`
- `https://triplan.ma/wp-content/uploads/2026/02/PADDLE-4-1024x1024.png`
- `https://triplan.ma/wp-content/uploads/2025/03/montgofliere-marrakech-6-1024x1024.png`
- `https://triplan.ma/wp-content/uploads/2025/03/parapente_triplan_1080x1080_correct-1024x1024.png`
- `https://triplan.ma/wp-content/uploads/2025/04/Karting-17-1024x1024.png`
- `https://triplan.ma/wp-content/uploads/2025/12/IMG_2075-1024x683.jpg`
- `https://triplan.ma/wp-content/uploads/2025/03/ChatGPT-Image-3-mars-2026-00_31_00.png`
- Reference partner-logo URLs listed in `client/src/data/content.ts`.
- Remote fallback and demo avatars are also listed in the image manifest.

Pages using reference-site imagery include the homepage, all destination and trip listings/details, activity pages, business page, about page, private travel page, reviews, and articles.

## Frontend-only placeholder features

Forms show polished validation and a success state but do not send data. Booking CTAs are inquiry links rather than real reservations or payment flows. Search and sort controls are present as the first frontend layer; only the destination selector is wired to a route target in this version. WhatsApp, phone, social, and email links are present but should be replaced with client-approved contacts. Review content is demo/reference-derived and should be verified and authorized before production use or structured review markup.

## Replacing remote images with licensed assets

1. Add approved image files outside the project folder, for example in `/home/ubuntu/webdev-static-assets/`.
2. Upload them with `manus-upload-file --webdev /path/to/asset.jpg`.
3. Replace only the corresponding values in `client/src/data/imageManifest.ts` with the returned `/manus-storage/...` paths.
4. Keep the descriptive manifest keys stable; components already use semantic alt text and lazy loading.
5. Remove any remaining reference-site URLs before production if the client does not have reuse permission.

## Connecting a real booking backend later

Replace the `InquiryForm` submit handler with a server endpoint or CRM integration. Validate the same fields on the server, store consent with timestamp and source, return a request ID, and make availability/pricing a server-owned source of truth. For payments, add a secure backend feature and never put payment secrets in this static frontend. Keep the frontend copy explicit about whether a request is a hold, confirmed booking, or inquiry.

## Sitemap generation

A starter static `client/public/sitemap.xml` is included. For production, replace its domain with the canonical deployment domain and generate route entries from the same local data arrays (`trips`, `destinations`, `activities`, and `articles`) during a build script. Submit the resulting URL in Search Console and keep `client/public/robots.txt` pointing to `/sitemap.xml`.

## Deployment

Run `pnpm install`, `pnpm check`, and `pnpm build`. The Vite output is generated under `dist/public`; the scaffold also produces `dist/index.js` for the provided static serving wrapper. Deploy the project using the WebDev publish workflow or any host that supports Vite static output with SPA fallback to `index.html`. Configure the final canonical domain in `SEO`, `robots.txt`, and `sitemap.xml` before launch.


## Portail client ajouté

Le portail client utilise `client/src/lib/auth.tsx` comme point central pour l’authentification et `client/src/pages/AccountPages.tsx` pour les écrans publics et protégés. La session de démonstration ne stocke jamais de mot de passe : seul un profil utilisateur non sensible est conservé localement pour permettre les tests frontend. Les appels de production sont centralisés dans `apiClient` et basculent temporairement sur des données de démonstration lorsque l’API n’est pas disponible.

### Routes compte

| Type | Routes |
|---|---|
| Auth publique | `/connexion`, `/inscription`, `/mot-de-passe-oublie`, `/reinitialiser-mot-de-passe`, `/verifier-email` |
| Compte protégé | `/mon-compte`, `/mon-compte/profil`, `/mon-compte/reservations`, `/mon-compte/reservations/:id`, `/mon-compte/paiements`, `/mon-compte/paiements/:id`, `/mon-compte/documents`, `/mon-compte/points-fidelite`, `/mon-compte/points-fidelite/recompenses`, `/mon-compte/galeries`, `/mon-compte/galeries/:id`, `/mon-compte/notifications`, `/mon-compte/securite`, `/mon-compte/parametres`, `/mon-compte/contact` |

### Flux d’authentification

`AuthProvider` restaure la session au chargement, expose `useAuth`, gère connexion, inscription, déconnexion et demande de réinitialisation, et maintient un état de chargement et d’erreur. `ProtectedRoute` redirige un visiteur vers `/connexion?redirect=...`; après connexion, l’URL originale est restaurée. `GuestRoute` évite qu’un utilisateur déjà connecté ne revienne sur les écrans d’authentification. Les erreurs de credentials, d’email non vérifié et de réseau sont rendues dans l’interface.

### Mapping API attendu

| Fonction frontend | Endpoint attendu |
|---|---|
| Connexion / inscription / session | `POST /api/auth/login`, `POST /api/auth/register`, `POST /api/auth/logout`, `POST /api/auth/refresh`, `GET /api/auth/me` |
| Mot de passe et vérification | `POST /api/auth/forgot-password`, `POST /api/auth/reset-password`, `POST /api/auth/verify-email`, `PATCH /api/auth/me/password` |
| Profil | `PATCH /api/auth/me` ou `PATCH /api/me/profile` |
| Réservations | `GET /api/me/reservations`, `GET /api/me/reservations/:id` |
| Paiements et documents | `GET /api/me/payments`, `GET /api/me/payments/:id`, `GET /api/me/payment-documents`, `GET /api/me/payment-documents/:id/download` |
| Fidélité | `GET /api/me/loyalty`, `GET /api/me/loyalty/transactions`, `GET /api/public/loyalty/rewards`, `POST /api/me/loyalty/rewards/:id/redeem` |
| Galeries | `GET /api/me/galleries`, `GET /api/me/galleries/:id`, `POST /api/me/galleries/:id/download-all`, `GET /api/me/galleries/assets/:assetId/download` |
| Notifications | `GET /api/me/notifications`, `PATCH /api/me/notifications/:id/read`, `POST /api/me/notifications/read-all` |
| Sécurité | `POST /api/auth/logout-all`, `POST /api/auth/verify-email` |

Adapter uniquement `apiClient` si les noms exacts diffèrent. Conserver des URLs signées et expirantes pour les téléchargements privés, ne jamais exposer de stockage permanent ou de données bancaires sensibles.

### Données client requises

Le portail attend au minimum un utilisateur `{ id, firstName, lastName, email, phone, verified, points, profileCompletion }`. Une réservation doit exposer référence, voyage, images autorisées, dates, participants, statut, total, payé, reste à régler, point de rendez-vous et timeline. Les paiements doivent exposer référence, réservation, date, montant, méthode masquée et statut. Les documents, galeries, assets, notifications, récompenses et transactions fidélité doivent être filtrés côté serveur par l’utilisateur authentifié.

### Flux fidélité

Le solde, le niveau et la progression sont visibles dans le wallet. Les récompenses affiche leur coût et leurs règles. Toute utilisation ouvre une confirmation indiquant le coût exact et le solde après opération; le branchement production devra ensuite créer un code de redemption côté serveur, déduire les points atomiquement et renvoyer la récompense dans le wallet. Le ledger distingue points gagnés, bonus, dépensés et expirés.

### Flux galerie

Seules les galeries autorisées apparaissent dans `/mon-compte/galeries`. La page détail offre filtres, grille, aperçu lightbox, téléchargement individuel et bouton « Télécharger tout ». En production, ce dernier doit lancer une génération ZIP asynchrone, afficher sa progression, puis télécharger une URL signée et expirante.

### Placeholders frontend

Les formulaires, réservations, paiements, documents, téléchargements, notifications, changement de mot de passe, récompenses, vérification email et préférences sont des démonstrations frontend. Aucun paiement, email, fichier privé ou mutation distante réelle n’est exécuté. Les données Yasmine, la réservation Mini-circuit du Nord, les points et les notifications sont des fixtures à remplacer par l’API. Les liens WhatsApp et email sont configurables dans le composant d’aide.

### Résultats de tests

Le parcours visiteur vers `/mon-compte` a redirigé vers `/connexion?redirect=%2Fmon-compte`. La connexion de démonstration a restauré `/mon-compte`, puis la navigation vers `/mon-compte/reservations`, `/mon-compte/points-fidelite` et `/mon-compte/points-fidelite/recompenses` a été vérifiée. La modal de confirmation de dépense de 500 points affiche bien le nouveau solde de 220 points. La console navigateur ne retourne aucun message. `pnpm check` et `pnpm build` réussissent; le build affiche seulement l’avertissement standard de chunk JS volumineux.

### Responsive

Les layouts ont été contrôlés en desktop et sur un viewport mobile 390 × 844. Le login devient une composition verticale avec image en tête, les cartes compte s’empilent, la navigation latérale devient un tiroir, les tableaux deviennent des cartes, la grille galerie passe à deux colonnes et les actions importantes occupent toute la largeur lorsque nécessaire. Les breakpoints couvrent également 520, 820 et 1050 px.

### Connexion à la production

1. Remplacer les fallbacks de `apiClient` par les réponses de l’API réelle et configurer la base URL selon l’environnement.
2. Utiliser des cookies HTTP-only sécurisés ou le mécanisme de refresh existant; ne jamais stocker un mot de passe ni un refresh token sensible dans le stockage navigateur.
3. Brancher les pages de profil, réservations, paiements, documents, fidélité, galeries et notifications sur des hooks de lecture avec cache et annulation des requêtes.
4. Ajouter les endpoints de mutation sécurisés, avec contrôle d’accès par utilisateur et journalisation côté serveur.
5. Remplacer les fixtures, vérifier les traductions françaises, connecter les emails et tester les statuts 401, 403, 404, 409, 422, 429 et 500 avant publication.


## Mise à jour Yallahmaana et fiches voyage

La bannière « Nouveaux départs d’automne · petits groupes, grands souvenirs » a été supprimée du layout global. Les coordonnées publiques utilisent désormais `bonjour@yallahmaana.com` et `https://yallahmaana.com` dans le contenu, les métadonnées, le sitemap et robots.txt.

Les fiches voyage disposent maintenant d’un champ optionnel `programHtml` sur le type `Trip`. Ce champ est rendu dans `.trip-program-html` avec un fallback généré depuis l’itinéraire lorsque le HTML n’est pas renseigné. L’objectif est de permettre à l’espace admin/API de fournir directement le programme éditorialisé en HTML : étapes, titres, descriptions, badges, tableaux ou blocs personnalisés. En production, le HTML devra être nettoyé côté serveur avec une allowlist de balises et attributs avant rendu; ne jamais accepter de HTML arbitraire non sanitisé depuis une saisie publique.

Chaque voyage affiche désormais une galerie éditoriale de 12 images, avec grille responsive, compteur, légendes numérotées, survols et composition asymétrique desktop/mobile. Les données restent des fixtures frontend et devront être remplacées par des URLs d’assets validées côté API/CMS.


## Parcours de réservation intégré

Le bouton « Demander une disponibilité » ouvre désormais un parcours inline dans la fiche voyage. L’étape 1 demande le nombre de personnes, l’étape 2 crée le compte avec prénom, nom, email, téléphone et mot de passe, puis l’étape 3 confirme la demande avec le départ et le lieu de rendez-vous. Un utilisateur déjà connecté passe directement à la confirmation. En mode frontend démo, la demande est persistée dans `localStorage` sous `yallahmaana_reservations` et le compte est géré par le fallback local de `client/src/lib/auth.tsx`; une API réelle devra remplacer ces fallbacks pour envoyer la demande à l’agence, vérifier l’email et créer une réservation définitive.


## Galerie et historique des réservations

Les images de la galerie voyage sont maintenant des boutons accessibles qui ouvrent une lightbox plein écran avec image agrandie, navigation précédent/suivant, fermeture par clic extérieur et compteur. Les demandes enregistrées dans `localStorage.yallahmaana_reservations` sont chargées dans `Mes réservations` avec statut, voyage, nombre de participants, date et lieu; la page conserve également la réservation de démonstration existante. Le formulaire de réservation utilise un spinner pendant la création du compte et une confirmation animée avec résumé visuel. Ces données restent locales dans le frontend tant que l’API de réservation n’est pas connectée.
