import { Toaster } from '@/components/ui/sonner'
import { Route, Switch } from 'wouter'
import { Layout } from '@/components/site'
import { AuthProvider } from '@/lib/auth'
import { GuestRoute, ProtectedRoute, LoginPage, RegisterPage, ForgotPasswordPage, ResetPasswordPage, VerifyEmailPage, DashboardPage, ProfilePage, ReservationsPage, ReservationDetailPage, PaymentsPage, PaymentDetailPage, DocumentsPage, LoyaltyPage, RewardsPage, GalleriesPage, GalleryDetailPage, NotificationsPage, SecurityPage, SettingsPage, HelpPage } from '@/pages/AccountPages'
import { AboutPage, ArticlePage, BusinessPage, ContactPage, DetailPage, FAQPage, Home, LegalPage, ListingPage, NotFoundPage, PrivatePage, ReviewsPage } from '@/pages/Pages'

function Router() {
  return <Switch>
    <Route path="/" component={Home}/>
    <Route path="/voyages" component={()=><ListingPage type="trips"/>}/>
    <Route path="/voyages/:slug" component={()=><DetailPage kind="trip"/>}/>
    <Route path="/destinations" component={()=><ListingPage type="destinations"/>}/>
    <Route path="/destinations/:slug" component={()=><DetailPage kind="destination"/>}/>
    <Route path="/activites" component={()=><ListingPage type="activities"/>}/>
    <Route path="/activites/:slug" component={()=><DetailPage kind="activity"/>}/>
    <Route path="/voyages-prives" component={PrivatePage}/>
    <Route path="/entreprises" component={BusinessPage}/>
    <Route path="/a-propos" component={AboutPage}/>
    <Route path="/avis" component={ReviewsPage}/>
    <Route path="/blog" component={()=><ListingPage type="articles"/>}/>
    <Route path="/blog/:slug" component={ArticlePage}/>
    <Route path="/contact" component={ContactPage}/>
    <Route path="/faq" component={FAQPage}/>
    <Route path="/mentions-legales" component={()=><LegalPage kind="legal"/>}/>
    <Route path="/politique-de-confidentialite" component={()=><LegalPage kind="privacy"/>}/>
    <Route path="/conditions-generales" component={()=><LegalPage kind="terms"/>}/>
    <Route path="/connexion" component={()=><GuestRoute><LoginPage/></GuestRoute>}/>
    <Route path="/inscription" component={()=><GuestRoute><RegisterPage/></GuestRoute>}/>
    <Route path="/mot-de-passe-oublie" component={()=><GuestRoute><ForgotPasswordPage/></GuestRoute>}/>
    <Route path="/reinitialiser-mot-de-passe" component={ResetPasswordPage}/>
    <Route path="/verifier-email" component={VerifyEmailPage}/>
    <Route path="/mon-compte" component={()=><ProtectedRoute><DashboardPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/profil" component={()=><ProtectedRoute><ProfilePage/></ProtectedRoute>}/>
    <Route path="/mon-compte/reservations/:id" component={()=><ProtectedRoute><ReservationDetailPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/reservations" component={()=><ProtectedRoute><ReservationsPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/paiements/:id" component={()=><ProtectedRoute><PaymentDetailPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/paiements" component={()=><ProtectedRoute><PaymentsPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/documents" component={()=><ProtectedRoute><DocumentsPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/points-fidelite/recompenses" component={()=><ProtectedRoute><RewardsPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/points-fidelite" component={()=><ProtectedRoute><LoyaltyPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/galeries/:id" component={()=><ProtectedRoute><GalleryDetailPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/galeries" component={()=><ProtectedRoute><GalleriesPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/notifications" component={()=><ProtectedRoute><NotificationsPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/securite" component={()=><ProtectedRoute><SecurityPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/parametres" component={()=><ProtectedRoute><SettingsPage/></ProtectedRoute>}/>
    <Route path="/mon-compte/contact" component={()=><ProtectedRoute><HelpPage/></ProtectedRoute>}/>
    <Route component={NotFoundPage}/>
  </Switch>
}

export default function App() {
  return <AuthProvider><Toaster position="bottom-right"/><Layout><Router/></Layout></AuthProvider>
}
