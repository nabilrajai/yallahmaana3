export type Price = { amount: number; currency: string; label?: string }
export type Availability = { seats: number; label: string; tone: 'green' | 'orange' | 'muted' }
export type ItineraryDay = { day: string; title: string; description: string; tag?: string }

export type Trip = {
  slug: string; title: string; region: string; excerpt: string; description: string; image: string; gallery: string[]; duration: string; price: Price; departure: string; availability: Availability; category: string; highlights: string[]; itinerary: ItineraryDay[]; included: string[]; excluded: string[]; accommodation: string; meetingPoint: string; programHtml?: string
}
export type Destination = { slug: string; name: string; region: string; intro: string; image: string; tripCount: number; bestFor: string[] }
export type Activity = { slug: string; title: string; location: string; excerpt: string; description: string; image: string; duration: string; price: Price; category: string; included: string[]; bring: string[]; gallery: string[] }
export type Article = { slug: string; title: string; category: string; excerpt: string; image: string; date: string; author: string; readingTime: string; content: string[] }
export type Testimonial = { name: string; trip: string; quote: string; avatar: string; date: string }
export type Partner = { name: string; image: string }
export type FAQ = { question: string; answer: string }
